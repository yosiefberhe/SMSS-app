import React from 'react';
import { Router } from './app/router/router';

export default function App() {

  return (
      <Router />
  );
}

