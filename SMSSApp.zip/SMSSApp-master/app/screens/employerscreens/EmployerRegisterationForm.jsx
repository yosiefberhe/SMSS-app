import React from 'react';
import { Text, View } from 'react-native';

function EmployerRegisterationForm(props) {
  return (
    
     <Text> Hello, this is Employer form. FROM EMPLOYER COMPONENT</Text>
    
  );
}

export default EmployerRegisterationForm;