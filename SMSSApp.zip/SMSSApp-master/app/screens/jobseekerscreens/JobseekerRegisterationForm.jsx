import React from 'react';
import { Text, View } from 'react-native';

function JobseekerRegisterationScreen(props) {
  return (
    
     <Text> Hello, this is Jobseeker form. FROM JOBSEEKER COMPONENT </Text>
    
  );
}

export default JobseekerRegisterationScreen;