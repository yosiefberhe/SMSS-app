 import React from 'react';
import { Text } from 'react-native';
 
 function Nav(props) {
   return (
     <Text>This is a nav bar.</Text>
   );
 }
 
 export default Nav;